import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, TextInput } from 'react-native';
import Indio from './assets/indio444.png';  // Importação correta da imagem
import { ScrollView } from 'react-native-web';

export default function App() {
  return (
    <View style={styles.container}>
      <ScrollView>
      <View style={styles.topo1}>
        <Text style={styles.txttopo}>23:59</Text>
      </View>

      <View style={styles.topo2}>
          <Image source={Indio} style={styles.imagem} />
          <View style={styles.topo3}>
          <Text style={styles.nome}>IndioDeluxe</Text>
          <Text style={styles.status}>Online</Text>
          </View>
      </View>

      <StatusBar style="auto" />

      <View style={styles.view1}>
        <View style={styles.viewesq}>
          <Text style={styles.conv}>Ou, tá livre 2 e 30?</Text>
          <Text style={styles.hrsesq}>12:37</Text>
        </View>
      </View>

      <View style={styles.view2}>
        <View style={styles.viewdir}>
          <Text style={styles.conv}>To, pq</Text>
          <Text style={styles.hrsdir}>12:37</Text>
        </View>
      </View>

      <View style={styles.view1}>
        <View style={styles.viewesq}>
          <Text style={styles.conv}>Tem um fut na oca do pajé</Text>
          <Text style={styles.hrsesq}>12:38</Text>
        </View>
      </View>

      <View style={styles.view2}>
        <View style={styles.viewdir}>
          <Text style={styles.conv}>Blz, mas c vai q hrs?</Text>
          <Text style={styles.hrsdir}>12:42</Text>
        </View>
      </View>

      <View style={styles.view1}>
        <View style={styles.viewesq}>
          <Text style={styles.conv}>Umas 2 hrs, quero ir cedo</Text>
          <Text style={styles.hrsesq}>12:43</Text>
        </View>
      </View>

      <View style={styles.view2}>
        <View style={styles.viewdir}>
          <Text style={styles.conv}>Pdp</Text>
          <Text style={styles.hrsdir}>12:54</Text>
        </View>
      </View>

      <View style={styles.view2}>
        <View style={styles.viewdir}>
          <Text style={styles.conv}>Leva outra butina pra eu jogar</Text>
          <Text style={styles.hrsdir}>13:48</Text>
        </View>
      </View>

      <View style={styles.view2}>
        <View style={styles.viewdir}>
          <Text style={styles.conv}>?????????</Text>
          <Text style={styles.hrsdir}>13:52</Text>
        </View>
      </View>

      <View style={styles.view1}>
        <View style={styles.viewesq}>
          <Text style={styles.conv}>Vou levar seboso da petrobras</Text>
          <Text style={styles.hrsesq}>14:07</Text>
        </View>
      </View>

      <View style={styles.view1}>
        <View style={styles.viewesq}>
          <Text style={styles.conv}>Passa na casa do Oclenis e chama ele</Text>
          <Text style={styles.hrsesq}>14:08</Text>
        </View>
      </View>

      <View style={styles.view2}>
        <View style={styles.viewdir}>
          <Text style={styles.conv}>Pdp resto de óleo motor</Text>
          <Text style={styles.hrsdir}>14:09</Text>
        </View>
      </View>

      <View style={styles.view1}>
        <View style={styles.viewesq}>
          <Text style={styles.conv}>Siferra kkkk</Text>
          <Text style={styles.hrsesq}>14:10</Text>
        </View>
      </View>

      <View style={styles.msgvw}>
        <TextInput style={styles.msg}></TextInput>
        <View style={styles.audio}></View>
      </View>

      <View style={styles.btns}></View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#d8d8d8',
    alignItems: 'center',
  },
  topo1: {
    backgroundColor: "#646464",
    height: 40,
    width: "100vw",
  },
  txttopo: {
    fontSize: 16,
    padding: 10,
    color: "white",
    marginLeft: 28,

  },
  topo2: {
    flex: 1,
    flexDirection:"row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#008055",
    height: 70,
    width: "100vw",
  },
  nome: {
    color: "white",
    fontWeight: "bold",
  },
  status: {
    color: "white",
  },
  imagemContainer: {
    flex: 1,
    flexDirection:"row",
    alignItems: 'center',
  },
  imagem: {
    height: 60,
    width: 60, 
    borderRadius: 50, 
    marginRight: 10,
  },
  view1: {
    flex: 1,
    justifyContent: "center",
    alignItems: "flex-start",
    width: '100%',
    marginLeft: 15,
  },
  view2: {
    flex: 1,
    justifyContent: "center",
    alignItems: "flex-end",
    width: '100%',
  },
  viewesq: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: "row",
    marginTop: 20,
    backgroundColor: "white",
    borderRadius: 10,
    marginLeft: 10,
  },
  viewdir: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: "row",
    marginTop: 20,
    backgroundColor: "#e0f1b8",
    borderRadius: 10,
    marginRight: 10,
  },
  conv: {
    fontSize: 18,
    padding: 15,
  },
  hrsesq: {
    paddingRight: 10,
    color: "#5e5e5e",
    marginTop: 10,
  },
  hrsdir: {
    paddingRight: 10,
    color: "#5e5e5e",
    marginTop: 10,
  },
  msgvw: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    width: "100vw",
    marginTop: 120,
  },
  msg: {
    padding: 20,
    width: "85vw",
    backgroundColor: "white",
    borderTopRightRadius: 0,
    borderRadius: 10,
  },
  audio: {
    backgroundColor: "#008055",
    height: 60,
    width: 60,
    marginLeft: 10,
    borderRadius: 999,
  },
  btns: {
    backgroundColor: "#292929",
    marginTop: 10,
    height: 60,
    width: "100vw",
  },
});
