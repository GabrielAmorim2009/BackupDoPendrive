import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, TextInput } from 'react-native';
import Indio from './assets/indio444.png';  // Importação correta da imagem
import { ScrollView } from 'react-native-web';

export default function App() {
  return (
    <View style={styles.container}>
      <ScrollView>
      <View style={styles.topo1}>
        <Text style={styles.txttopo}>23:59</Text>
      </View>

      <View style={styles.topo2}>
          <Image source={Indio} style={styles.imagem} />
          <View style={styles.topo3}>
          <Text style={styles.nome}>IndioDeluxe</Text>
          <Text style={styles.status}>Online</Text>
          </View>
      </View>

      <StatusBar style="auto" />

      <View style={styles.view1}>
        <View style={styles.viewesq}>
          <Text style={styles.conv}>Oi como você está?</Text>
          <Text style={styles.hrsesq}>23:57</Text>
        </View>
      </View>

      <View style={styles.view2}>
        <View style={styles.viewdir}>
          <Text style={styles.conv}>Oi, to suave</Text>
          <Text style={styles.hrsdir}>23:57</Text>
        </View>
      </View>

      <View style={styles.view1}>
        <View style={styles.viewesq}>
          <Text style={styles.conv}>Bala</Text>
          <Text style={styles.hrsesq}>23:57</Text>
        </View>
      </View>

      <View style={styles.view2}>
        <View style={styles.viewdir}>
          <Text style={styles.conv}>ou</Text>
          <Text style={styles.hrsdir}>23:57</Text>
        </View>
      </View>

      <View style={styles.view1}>
        <View style={styles.viewesq}>
          <Text style={styles.conv}>Salve mano tudo bom?</Text>
          <Text style={styles.hrsesq}>23:57</Text>
        </View>
      </View>

      <View style={styles.view2}>
        <View style={styles.viewdir}>
          <Text style={styles.conv}>Vamo jogar Free Fire?</Text>
          <Text style={styles.hrsdir}>23:57</Text>
        </View>
      </View>

      <View style={styles.view2}>
        <View style={styles.viewdir}>
          <Text style={styles.conv}>Me responde ai cara</Text>
          <Text style={styles.hrsdir}>23:58</Text>
        </View>
      </View>

      <View style={styles.view2}>
        <View style={styles.viewdir}>
          <Text style={styles.conv}>?????????</Text>
          <Text style={styles.hrsdir}>23:59</Text>
        </View>
      </View>

      <View style={styles.view1}>
        <View style={styles.viewesq}>
          <Text style={styles.conv}>Calma ae fe to jantando terra</Text>
          <Text style={styles.hrsesq}>00:07</Text>
        </View>
      </View>

      <View style={styles.msgvw}>
        <TextInput style={styles.msg}></TextInput>
        <View style={styles.audio}></View>
      </View>

      <View style={styles.btns}></View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#d8d8d8',
    alignItems: 'center',
  },
  topo1: {
    backgroundColor: "#646464",
    height: 40,
    width: "100vw",
  },
  txttopo: {
    fontSize: 16,
    padding: 10,
    color: "white",
    marginLeft: 28,

  },
  topo2: {
    flex: 1,
    flexDirection:"row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#008055",
    height: 70,
    width: "100vw",
  },
  nome: {
    color: "white",
    fontWeight: "bold",
  },
  status: {
    color: "white",
  },
  imagemContainer: {
    flex: 1,
    flexDirection:"row",
    alignItems: 'center',
  },
  imagem: {
    height: 60,
    width: 60, 
    borderRadius: 50, 
    marginRight: 10,
  },
  view1: {
    flex: 1,
    justifyContent: "center",
    alignItems: "flex-start",
    width: '100%',
    marginLeft: 15,
  },
  view2: {
    flex: 1,
    justifyContent: "center",
    alignItems: "flex-end",
    width: '100%',
  },
  viewesq: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: "row",
    marginTop: 20,
    backgroundColor: "white",
    borderRadius: 10,
    marginLeft: 10,
  },
  viewdir: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: "row",
    marginTop: 20,
    backgroundColor: "#e0f1b8",
    borderRadius: 10,
    marginRight: 10,
  },
  conv: {
    fontSize: 18,
    padding: 15,
  },
  hrsesq: {
    paddingRight: 10,
    color: "#5e5e5e",
    marginTop: 10,
  },
  hrsdir: {
    paddingRight: 10,
    color: "#5e5e5e",
    marginTop: 10,
  },
  msgvw: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    backgroundColor: "blue",
    width: "100vw",
    marginTop: 120,
  },
  msg: {
    padding: 20,
    width: 300,
    backgroundColor: "white",
    borderTopRightRadius: 0,
    borderRadius: 10,
  },
  audio: {
    backgroundColor: "#008055",
    height: 60,
    width: 60,
    marginLeft: 10,
    borderRadius: 999,
  },
  btns: {
    backgroundColor: "#292929",
    marginTop: 10,
    height: 60,
    width: "100vw",
  },
});
